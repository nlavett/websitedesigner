﻿using Microsoft.AspNetCore.Mvc.Rendering;

namespace IdeaShare.Models
{
    public class InputBoxes
    {
        public SelectList coscInput = new SelectList(new[]
        {
                    new SelectListItem {Selected = true, Text = "---- Select a category ----", Value = "Garbage"},
                    new SelectListItem {Selected = false, Text = "Java", Value = "Java"},
                    new SelectListItem {Selected = false, Text = "Linux", Value = "Linux"}, 
                }, "Value", "Text"); 
    }
}
