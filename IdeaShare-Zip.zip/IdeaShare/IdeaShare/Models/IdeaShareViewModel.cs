﻿namespace IdeaShare.Models
{
    public class IdeaShareViewModel
    {

        public string? coscUserInput { get; set; }

        public string? businessUserInput { get; set; }

        public string? artUserInput { get; set; }

        public string? cookingUserInput { get; set; }

        public string? storiesUserInput { get; set; }

        public string? loginUserInput { get; set; }

        public string? signupUserInput { get; set; }
 
        public string? coscSelectedValue { get; set; }

        public string? businessSelectedValue { get; set; }

        public string? artSelectedValue { get; set; }

        public string? cookingSelectedValue { get; set; }

        public string? storiesSelectedValue { get; set; }

    }
}
