﻿using IdeaShare.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Data.SqlClient;
using System.Data;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace IdeaShare.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult About()
        {
            return View();
        }

        public IActionResult Login(IdeaShareViewModel idea)
        {
            return View(idea);
        }

        [HttpPost]
        public ActionResult SaveRecordLogin(IdeaShareViewModel idea)
        {
            SqlConnection con = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=ideasharedb;Trusted_Connection=True;");
            SqlCommand cmd = new SqlCommand("sp_user_add", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@username", "user1");
            cmd.Parameters.AddWithValue("@password", idea.loginUserInput);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            return RedirectToAction("Index");
        }

        public IActionResult Signup(IdeaShareViewModel idea)
        {
            return View(idea);
        }

        [HttpPost]
        public ActionResult SaveRecordSignup(IdeaShareViewModel idea)
        {
            SqlConnection con = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=ideasharedb;Trusted_Connection=True;");
            SqlCommand cmd = new SqlCommand("sp_user_add", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@username", "user2");
            cmd.Parameters.AddWithValue("@password", idea.signupUserInput);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            return RedirectToAction("Index");
        }

        public IActionResult Cosc(IdeaShareViewModel idea)
        {
            List<string> coscList = new List<string>();
            coscList.AddRange(new string[] { "Java", "Python", "C+", "Linux", "Website", "Research" });
            ViewBag.coscDropDownList = new SelectList(coscList);

            //List<string> coscColData = new List<string>();

            //using (SqlConnection con = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=ideasharedb;Trusted_Connection=True;"))
            //{
            //    con.Open();
            //    string query = "SELECT IdeaInput FROM dbo.cosc";
            //    using (SqlCommand cmd = new SqlCommand(query, con))
            //    {
            //        using (SqlDataReader reader = cmd.ExecuteReader())
            //        {
            //            while (reader.Read())
            //            {
            //                coscColData.Add(reader.GetString(0));
            //            }
            //        }
            //    }
            //}

            //ViewData["CoscViewData"] = coscColData;


            //if you want to separate into different categories

            List<string> coscPython = new List<string>();
            using (SqlConnection con = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=ideasharedb;Trusted_Connection=True;"))
            {
                con.Open();
                string query = "SELECT IdeaInput FROM dbo.cosc WHERE Category = 'Python'";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            coscPython.Add(reader.GetString(0));
                        }
                    }
                }
            }
            ViewData["CoscViewPython"] = coscPython;

            List<string> coscLinux = new List<string>();
            using (SqlConnection con = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=ideasharedb;Trusted_Connection=True;"))
            {
                con.Open();
                string query = "SELECT IdeaInput FROM dbo.cosc WHERE Category = 'Linux'";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            coscLinux.Add(reader.GetString(0));
                        }
                    }
                }
            }
            ViewData["CoscViewLinux"] = coscLinux;

            List<string> coscJava = new List<string>();
            using (SqlConnection con = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=ideasharedb;Trusted_Connection=True;"))
            {
                con.Open();
                string query = "SELECT IdeaInput FROM dbo.cosc WHERE Category = 'Java'";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            coscJava.Add(reader.GetString(0));
                        }
                    }
                }
            }
            ViewData["CoscViewJava"] = coscJava;

            List<string> coscC = new List<string>();
            using (SqlConnection con = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=ideasharedb;Trusted_Connection=True;"))
            {
                con.Open();
                string query = "SELECT IdeaInput FROM dbo.cosc WHERE Category = 'C+'";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            coscC.Add(reader.GetString(0));
                        }
                    }
                }
            }
            ViewData["CoscViewC"] = coscC;

            List<string> coscWebsite = new List<string>();
            using (SqlConnection con = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=ideasharedb;Trusted_Connection=True;"))
            {
                con.Open();
                string query = "SELECT IdeaInput FROM dbo.cosc WHERE Category = 'Website'";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            coscWebsite.Add(reader.GetString(0));
                        }
                    }
                }
            }
            ViewData["CoscViewWebsite"] = coscWebsite;

            List<string> coscResearch = new List<string>();
            using (SqlConnection con = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=ideasharedb;Trusted_Connection=True;"))
            {
                con.Open();
                string query = "SELECT IdeaInput FROM dbo.cosc WHERE Category = 'Research'";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            coscResearch.Add(reader.GetString(0));
                        }
                    }
                }
            }
            ViewData["CoscViewResearch"] = coscResearch;


            return View(idea);
        }

        [HttpPost] public ActionResult SaveRecordCosc (IdeaShareViewModel idea)
        {
            SqlConnection con = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=ideasharedb;Trusted_Connection=True;");
            SqlCommand cmd = new SqlCommand("sp_cosc_add", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Category", idea.coscSelectedValue);
            cmd.Parameters.AddWithValue("@IdeaInput", idea.coscUserInput);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            return RedirectToAction("Index");
        }

        public IActionResult Business(IdeaShareViewModel idea)
        {
            List<string> businessList = new List<string>();
            businessList.AddRange(new string[] { "Accounting", "Marketing", "Sports Analytics", "Economics", "Investing", "Concepts" });
            ViewBag.businessDropDownList = new SelectList(businessList);

            List<string> buinessAccounting = new List<string>();
            using (SqlConnection con = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=ideasharedb;Trusted_Connection=True;"))
            {
                con.Open();
                string query = "SELECT IdeaInput FROM dbo.business WHERE Category = 'Accounting'";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            buinessAccounting.Add(reader.GetString(0));
                        }
                    }
                }
            }
            ViewData["BusinessViewAccounting"] = buinessAccounting;

            List<string> buinessMarketing = new List<string>();
            using (SqlConnection con = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=ideasharedb;Trusted_Connection=True;"))
            {
                con.Open();
                string query = "SELECT IdeaInput FROM dbo.business WHERE Category = 'Marketing'";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            buinessMarketing.Add(reader.GetString(0));
                        }
                    }
                }
            }
            ViewData["BusinessViewMarketing"] = buinessMarketing;

            List<string> buinessSports = new List<string>();
            using (SqlConnection con = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=ideasharedb;Trusted_Connection=True;"))
            {
                con.Open();
                string query = "SELECT IdeaInput FROM dbo.business WHERE Category = 'Sports Analytics'";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            buinessSports.Add(reader.GetString(0));
                        }
                    }
                }
            }
            ViewData["BusinessViewSports"] = buinessSports;

            List<string> buinessEconomics = new List<string>();
            using (SqlConnection con = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=ideasharedb;Trusted_Connection=True;"))
            {
                con.Open();
                string query = "SELECT IdeaInput FROM dbo.business WHERE Category = 'Economics'";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            buinessEconomics.Add(reader.GetString(0));
                        }
                    }
                }
            }
            ViewData["BusinessViewEconomics"] = buinessEconomics;

            List<string> buinessInvesting = new List<string>();
            using (SqlConnection con = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=ideasharedb;Trusted_Connection=True;"))
            {
                con.Open();
                string query = "SELECT IdeaInput FROM dbo.business WHERE Category = 'Investing'";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            buinessInvesting.Add(reader.GetString(0));
                        }
                    }
                }
            }
            ViewData["BusinessViewInvesting"] = buinessInvesting;

            List<string> buinessConcepts = new List<string>();
            using (SqlConnection con = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=ideasharedb;Trusted_Connection=True;"))
            {
                con.Open();
                string query = "SELECT IdeaInput FROM dbo.business WHERE Category = 'Concepts'";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            buinessConcepts.Add(reader.GetString(0));
                        }
                    }
                }
            }
            ViewData["BusinessViewConcepts"] = buinessConcepts;

            return View(idea);
        }

        [HttpPost]
        public ActionResult SaveRecordBusiness(IdeaShareViewModel idea)
        {
            SqlConnection con = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=ideasharedb;Trusted_Connection=True;");
            SqlCommand cmd = new SqlCommand("sp_business_add", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Category", idea.businessSelectedValue);
            cmd.Parameters.AddWithValue("@IdeaInput", idea.businessUserInput);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            return RedirectToAction("Index");
        }
        public IActionResult Art(IdeaShareViewModel idea)
        {
            List<string> artList = new List<string>();
            artList.AddRange(new string[] { "Painting", "Architecture", "Modern", "Sculpture" });
            ViewBag.artDropDownList = new SelectList(artList);

            List<string> artPainting = new List<string>();
            using (SqlConnection con = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=ideasharedb;Trusted_Connection=True;"))
            {
                con.Open();
                string query = "SELECT IdeaInput FROM dbo.art WHERE Category = 'Painting'";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            artPainting.Add(reader.GetString(0));
                        }
                    }
                }
            }
            ViewData["ArtViewPainting"] = artPainting;

            List<string> artArchitecture = new List<string>();
            using (SqlConnection con = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=ideasharedb;Trusted_Connection=True;"))
            {
                con.Open();
                string query = "SELECT IdeaInput FROM dbo.art WHERE Category = 'Architecture'";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            artArchitecture.Add(reader.GetString(0));
                        }
                    }
                }
            }
            ViewData["ArtViewArchitecture"] = artArchitecture;

            List<string> artModern = new List<string>();
            using (SqlConnection con = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=ideasharedb;Trusted_Connection=True;"))
            {
                con.Open();
                string query = "SELECT IdeaInput FROM dbo.art WHERE Category = 'Modern'";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            artModern.Add(reader.GetString(0));
                        }
                    }
                }
            }
            ViewData["ArtViewModern"] = artModern;

            List<string> artSculpture = new List<string>();
            using (SqlConnection con = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=ideasharedb;Trusted_Connection=True;"))
            {
                con.Open();
                string query = "SELECT IdeaInput FROM dbo.art WHERE Category = 'Sculpture'";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            artSculpture.Add(reader.GetString(0));
                        }
                    }
                }
            }
            ViewData["ArtViewSculpture"] = artSculpture;

            return View(idea);
        }

        [HttpPost]
        public ActionResult SaveRecordArt(IdeaShareViewModel idea)
        {
            SqlConnection con = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=ideasharedb;Trusted_Connection=True;");
            SqlCommand cmd = new SqlCommand("sp_art_add", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Category", idea.artSelectedValue);
            cmd.Parameters.AddWithValue("@IdeaInput", idea.artUserInput);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            return RedirectToAction("Index");
        }

        public IActionResult Cooking(IdeaShareViewModel idea)
        {
            List<string> cookingList = new List<string>();
            cookingList.AddRange(new string[] { "Italian", "Japanese", "American" });
            ViewBag.cookingDropDownList = new SelectList(cookingList);

            List<string> cookingItalian = new List<string>();
            using (SqlConnection con = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=ideasharedb;Trusted_Connection=True;"))
            {
                con.Open();
                string query = "SELECT IdeaInput FROM dbo.cooking WHERE Category = 'Italian'";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            cookingItalian.Add(reader.GetString(0));
                        }
                    }
                }
            }
            ViewData["CookingViewItalian"] = cookingItalian;

            List<string> cookingJapanese = new List<string>();
            using (SqlConnection con = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=ideasharedb;Trusted_Connection=True;"))
            {
                con.Open();
                string query = "SELECT IdeaInput FROM dbo.cooking WHERE Category = 'Japanese'";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            cookingJapanese.Add(reader.GetString(0));
                        }
                    }
                }
            }
            ViewData["CookingViewJapanese"] = cookingJapanese;

            List<string> cookingAmerican = new List<string>();
            using (SqlConnection con = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=ideasharedb;Trusted_Connection=True;"))
            {
                con.Open();
                string query = "SELECT IdeaInput FROM dbo.cooking WHERE Category = 'American'";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            cookingAmerican.Add(reader.GetString(0));
                        }
                    }
                }
            }
            ViewData["CookingViewAmerican"] = cookingAmerican;

            return View(idea);
        }

        [HttpPost]
        public ActionResult SaveRecordCooking(IdeaShareViewModel idea)
        {
            SqlConnection con = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=ideasharedb;Trusted_Connection=True;");
            SqlCommand cmd = new SqlCommand("sp_cooking_add", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Category", idea.cookingSelectedValue);
            cmd.Parameters.AddWithValue("@IdeaInput", idea.cookingUserInput);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            return RedirectToAction("Index");
        }

        public IActionResult Stories(IdeaShareViewModel idea)
        {
            List<string> storiesList = new List<string>();
            storiesList.AddRange(new string[] { "Fantasy", "History", "Comedy", "Mystery", "Tragedy", "Adventure" });
            ViewBag.storiesDropDownList = new SelectList(storiesList);

            List<string> storiesFantasy = new List<string>();
            using (SqlConnection con = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=ideasharedb;Trusted_Connection=True;"))
            {
                con.Open();
                string query = "SELECT IdeaInput FROM dbo.stories WHERE Category = 'Fantasy'";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            storiesFantasy.Add(reader.GetString(0));
                        }
                    }
                }
            }
            ViewData["StoriesViewFantasy"] = storiesFantasy;

            List<string> storiesHistory = new List<string>();
            using (SqlConnection con = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=ideasharedb;Trusted_Connection=True;"))
            {
                con.Open();
                string query = "SELECT IdeaInput FROM dbo.stories WHERE Category = 'History'";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            storiesHistory.Add(reader.GetString(0));
                        }
                    }
                }
            }
            ViewData["StoriesViewHistory"] = storiesHistory;

            List<string> storiesComedy = new List<string>();
            using (SqlConnection con = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=ideasharedb;Trusted_Connection=True;"))
            {
                con.Open();
                string query = "SELECT IdeaInput FROM dbo.stories WHERE Category = 'Comedy'";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            storiesComedy.Add(reader.GetString(0));
                        }
                    }
                }
            }
            ViewData["StoriesViewComedy"] = storiesComedy;

            List<string> storiesMystery = new List<string>();
            using (SqlConnection con = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=ideasharedb;Trusted_Connection=True;"))
            {
                con.Open();
                string query = "SELECT IdeaInput FROM dbo.stories WHERE Category = 'Mystery'";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            storiesMystery.Add(reader.GetString(0));
                        }
                    }
                }
            }
            ViewData["StoriesViewMystery"] = storiesMystery;

            List<string> storiesTragedy = new List<string>();
            using (SqlConnection con = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=ideasharedb;Trusted_Connection=True;"))
            {
                con.Open();
                string query = "SELECT IdeaInput FROM dbo.stories WHERE Category = 'Tragedy'";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            storiesTragedy.Add(reader.GetString(0));
                        }
                    }
                }
            }
            ViewData["StoriesViewTragedy"] = storiesTragedy;

            List<string> storiesAdventure = new List<string>();
            using (SqlConnection con = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=ideasharedb;Trusted_Connection=True;"))
            {
                con.Open();
                string query = "SELECT IdeaInput FROM dbo.stories WHERE Category = 'Adventure'";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            storiesAdventure.Add(reader.GetString(0));
                        }
                    }
                }
            }
            ViewData["StoriesViewAdventure"] = storiesAdventure;

            return View(idea);
        }

        [HttpPost]
        public ActionResult SaveRecordStories(IdeaShareViewModel idea)
        {
            SqlConnection con = new SqlConnection("Server=localhost\\SQLEXPRESS;Database=ideasharedb;Trusted_Connection=True;");
            SqlCommand cmd = new SqlCommand("sp_stories_add", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Category", idea.storiesSelectedValue);
            cmd.Parameters.AddWithValue("@IdeaInput", idea.storiesUserInput);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            return RedirectToAction("Index");
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}